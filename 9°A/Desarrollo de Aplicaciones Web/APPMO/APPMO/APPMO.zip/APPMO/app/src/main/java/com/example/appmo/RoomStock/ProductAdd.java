package com.example.appmo.RoomStock;


import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.appmo.R;
import com.example.appmo.infoIP;

import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProductAdd extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    public static ManagerFragmentRoomStock state;
    String ip = new infoIP().getIp();

    View view;
    EditText txtName, txtQuantity, txtPrice;
    ImageView btnSave, btnCancel;
    ProgressDialog progress;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;

    public ProductAdd() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_product, container, false);
        saveProduct();
        return view;
    }

    private void saveProduct() {
        txtName = view.findViewById(R.id.txtRfc);
        txtQuantity = view.findViewById(R.id.txtNumberPhone);
        txtPrice = view.findViewById(R.id.txtMail);

        request = Volley.newRequestQueue(getContext());


        btnSave = view.findViewById(R.id.btnSaveClient);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarWebService();
            }
        });
        btnCancel = view.findViewById(R.id.btnCancelClient);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertCancel();

            }
        });


    }

    private void cargarWebService() {
        progress = new ProgressDialog(getContext());
        progress.setMessage(getString(R.string.load));
        progress.show();

        String url = "http://" + ip  + "/appmo/addProduct.php?name=" + txtName.getText().toString() +
                "&quantity=" + txtQuantity.getText().toString() +
                "&price=" + txtPrice.getText().toString();

        url = url.replace(" ", "%20");

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        request.add(jsonObjectRequest);


    }

    private void alertCancel() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                getContext());
        alertDialogBuilder.setTitle(getString(R.string.alertExit));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                changeFragment(ManagerFragmentRoomStock.ROOMSTOCKINDEX);
            }
        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }


    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getContext(), getString(R.string.susessfull), Toast.LENGTH_SHORT).show();
        progress.hide();
        txtName.setText("");
        txtQuantity.setText("");
        txtPrice.setText("");
        changeFragment(ManagerFragmentRoomStock.ROOMSTOCKINDEX);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        progress.hide();
        Toast.makeText(getContext(), getString(R.string.insusessfull) + error, Toast.LENGTH_SHORT).show();

    }

    private void changeFragment(ManagerFragmentRoomStock state) {
        this.state = ManagerFragmentRoomStock.setState(state);
        this.state.execute((MainContainerRoomStock) getContext());
    }


}
