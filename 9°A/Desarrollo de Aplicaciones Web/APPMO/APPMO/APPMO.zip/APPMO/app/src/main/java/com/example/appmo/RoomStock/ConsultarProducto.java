package com.example.appmo.RoomStock;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.example.appmo.R;

import org.json.JSONObject;


public class ConsultarProducto extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    View view;
    EditText txtSearchName;
    TextView txtQuantity, txtPrice;
    Button btnSearchProduct;

    public ConsultarProducto() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_consultar_producto, container, false);
        searchProduct();
        return view;
    }

    private void searchProduct() {
        txtSearchName = view.findViewById(R.id.txtSearchName);
        txtQuantity = view.findViewById(R.id.txtNumberPhone);
        txtPrice = view.findViewById(R.id.txtMail);
        btnSearchProduct = view.findViewById(R.id.btnSearchProduct);

        btnSearchProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWebService();
            }
        });

    }

    private void loadWebService() {

    }


    @Override
    public void onResponse(JSONObject response) {

    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }


}
