package com.example.appmo.Index;


public class Order {
    private int idOrder;
    private String nameOrder;
    private String qualitityOrder;
    private String destinationOrder;

    public Order(int idOrder, String nameOrder, String qualitityOrder, String destinationOrder) {
        this.idOrder = idOrder;
        this.nameOrder = nameOrder;
        this.qualitityOrder = qualitityOrder;
        this.destinationOrder = destinationOrder;
    }

    public int getIdOrder() {
        return idOrder;
    }

    public void setIdOrder(int idOrder) {
        this.idOrder = idOrder;
    }

    public String getNameOrder() {
        return nameOrder;
    }

    public void setNameOrder(String nameOrder) {
        this.nameOrder = nameOrder;
    }

    public String getQualitityOrder() {
        return qualitityOrder;
    }

    public void setQualitityOrder(String qualitityOrder) {
        this.qualitityOrder = qualitityOrder;
    }

    public String getDestinationOrder() {
        return destinationOrder;
    }

    public void setDestinationOrder(String destinationOrder) {
        this.destinationOrder = destinationOrder;
    }
}

