package com.example.appmo.Index;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.appmo.R;

import java.util.List;


public class OderAdapter extends RecyclerView.Adapter<OderAdapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Order> orderList;

    //getting the context and product list with constructor
    public OderAdapter(Context mCtx, List<Order> productList) {
        this.mCtx = mCtx;
        this.orderList = productList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_view_index, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        //getting the product of the specified position
        Order order = orderList.get(position);


        //binding the data with the viewholder views
        holder.tvNameOrder.setText(order.getNameOrder());
        holder.tvQualitityOrder.setText(order.getQualitityOrder());
        holder.tvDestinationOrder.setText(order.getDestinationOrder());

        holder.showAdpaterDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        holder.showAdpaterDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder showAlert = new AlertDialog.Builder(mCtx);
                showAlert.setTitle(R.string.dateorder)
                        .setMessage("Nombre: " + holder.tvNameOrder.getText() + "\n" +
                                "Cantidad: " + holder.tvQualitityOrder.getText() + "\n" +
                                "Destino: " + holder.tvDestinationOrder.getText())
                        .setNegativeButton((R.string.cancel), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        })
                        .setPositiveButton((R.string.accept), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {


                            }
                        });

                showAlert.create();
                showAlert.show();
            }
        });

    }


    @Override
    public int getItemCount() {
        return orderList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView tvNameOrder, tvQualitityOrder, tvDestinationOrder;
        ImageView showAdpaterDate;

        public ProductViewHolder(View itemView) {
            super(itemView);

            tvNameOrder = itemView.findViewById(R.id.tvNameProductRoomCheck);
            tvQualitityOrder = itemView.findViewById(R.id.tvTypeProductRoomCheck);
            tvDestinationOrder = itemView.findViewById(R.id.tvQuantityProductRoomCheck);
            showAdpaterDate = itemView.findViewById(R.id.showAdapterDate);
        }
    }
}