package com.example.appmo.Client;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.appmo.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ClientIndex extends Fragment {
    public static ManagerFragmentClient state;
    View view;


    public ClientIndex() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_client_index, container, false);
        addClient();
        cardview();
        return view;
    }

    private void cardview() {
    }

    private void addClient() {
        FloatingActionButton addUser ;
        addUser = view.findViewById(R.id.fabAddClient);
        addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(ManagerFragmentClient.CLIENTADD);
            }
        });
    }

    private void changeFragment(ManagerFragmentClient state) {
        this.state = ManagerFragmentClient.setState(state);
        this.state.execute((MainContainerClient) getContext());
    }

}
