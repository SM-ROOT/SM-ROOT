package com.example.appmo.Index;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;

import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.appmo.Client.MainContainerClient;
import com.example.appmo.Production.MainContainerProduction;
import com.example.appmo.R;
import com.example.appmo.Recipe.MainContainerRecipe;
import com.example.appmo.Supply.MainContainerSupply;
import com.example.appmo.RoomCheck.MainContainerRoomCheck;
import com.example.appmo.RoomStock.MainContainerRoomStock;
import com.example.appmo.Sell.MainContainerSell;
import com.example.appmo.User.MainContainerUser;

public class MainContainerIndex extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    public static ManagerFragmentIndex states;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.finished:
                    changeFragment(ManagerFragmentIndex.FINISHED);
                    showToolBarF();
                    return true;
                case R.id.start:
                    changeFragment(ManagerFragmentIndex.NO_START);
                    showToolBarNF();
                    return true;


            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.container_drawer);
        changeFragment(ManagerFragmentIndex.NO_START);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        BottomNavigationView navigation = findViewById(R.id.navIndex);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private void showToolBarF() {

        Toolbar toolbar = findViewById(R.id.toolbar);

        if (toolbar.getVisibility() == View.GONE) {
            toolbar.setVisibility(View.VISIBLE);
        }
        showToolBarFinished();

    }

    private void showToolBarFinished() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);
        final ActionBar actionBar = this.getSupportActionBar();
        actionBar.setTitle(getString(R.string.Finished));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    private void showToolBarNF() {

        Toolbar toolbar = findViewById(R.id.toolbar);

        if (toolbar.getVisibility() == View.GONE) {
            toolbar.setVisibility(View.VISIBLE);
        }
        showToolBarNoFinished();

    }

    private void showToolBarNoFinished() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);
        final ActionBar actionBar = this.getSupportActionBar();
        actionBar.setTitle(getString(R.string.noStart));
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle nav_index view item clicks here.
        int id = item.getItemId();

        if (id == R.id.roomStock) {
            Intent intentRoomStock = new Intent(MainContainerIndex.this, MainContainerRoomStock.class);
            startActivity(intentRoomStock);

        } else if (id == R.id.getResourse) {
            Intent intentReport = new Intent(MainContainerIndex.this, MainContainerSupply.class );
            startActivity(intentReport);

        } else if (id == R.id.client) {
            Intent intentClient= new Intent(MainContainerIndex.this, MainContainerClient.class);
            startActivity(intentClient);

        } else if (id == R.id.recipe) {
            Intent intentRecipe = new Intent(MainContainerIndex.this, MainContainerRecipe.class);
            startActivity(intentRecipe);

        } else if (id == R.id.roomCheck) {
            Intent intentRoomCheck = new Intent(MainContainerIndex.this, MainContainerRoomCheck.class);
            startActivity(intentRoomCheck);

        } else if (id == R.id.production) {
            Intent intentProduction = new Intent(MainContainerIndex.this, MainContainerProduction.class);
            startActivity(intentProduction);

        } else if (id == R.id.user) {
            Intent intentUser = new Intent(MainContainerIndex.this, MainContainerUser.class);
            startActivity(intentUser);

        } else if (id == R.id.sell) {
            Intent intentSell = new Intent(MainContainerIndex.this, MainContainerSell.class);
            startActivity(intentSell);

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0) {
            openAlert();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void openAlert() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                this);
        alertDialogBuilder.setTitle(getString(R.string.messageAlertTitle))
                .setMessage(getString(R.string.messageAlertAccept) + "\n" +
                        getString(R.string.cancel));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                System.exit(0);
            }
        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent intent = new Intent(getApplicationContext(), CloseAppClase.class); //Clear all activities and start new task
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    public void changeFragment(ManagerFragmentIndex states) {
        this.states = ManagerFragmentIndex.setState(states);
        this.states.execute(this);
    }
}
