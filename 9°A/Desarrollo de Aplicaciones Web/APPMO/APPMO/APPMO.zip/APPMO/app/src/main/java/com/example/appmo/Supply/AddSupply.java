package com.example.appmo.Supply;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.appmo.R;
import com.example.appmo.infoIP;

import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 */
public class AddSupply extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    public static ManagerFragmentSupply state;
    String ip = new infoIP().getIp();
    View view;
    TextView txtCorporationName, txtNumberPhone, txtMail, txtNameAddres, txtNumberAddres,
            txtCP, txtLocation, txtCity, txtState, txtCountry;

    ImageView btnSaveSupply, btnCancelSupply;


    ProgressDialog progreso;

    /**
     * Para establecer la conexion directa con el Web Service
     */
    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;


    public AddSupply() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_supply, container, false);
        backButton();
        saveSupply();
        showToolBar();
        return view;
    }

    private void showToolBar() {
        Toolbar toolbar = view.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        final ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        actionBar.setTitle(getString(R.string.addSupply));
        /*toolbar.setNavigationOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });*/

    }

    private void saveSupply() {

        txtCorporationName = view.findViewById(R.id.txtRfc);
        txtNumberPhone = view.findViewById(R.id.txtSubNamePather);
        txtMail = view.findViewById(R.id.txtMail);
        txtNameAddres = view.findViewById(R.id.txtNameAddres);
        txtNumberAddres = view.findViewById(R.id.txtNumberAddres);
        txtCP = view.findViewById(R.id.txtCp);
        txtLocation = view.findViewById(R.id.txtColony);
        txtCity = view.findViewById(R.id.txtCity);
        txtState = view.findViewById(R.id.txtState);
        txtCountry = view.findViewById(R.id.txtCountry);

        request = Volley.newRequestQueue(getContext());

        btnSaveSupply = view.findViewById(R.id.btnSaveUser);
        btnSaveSupply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //validation();
                cargarWebService();

            }
        });
        btnCancelSupply = view.findViewById(R.id.btnCancelUser);
        btnCancelSupply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertExit();
            }
        });
    }

    private void cargarWebService() {
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("Cargando...");
        progreso.show();


        String url = "http://" + ip + "/appmo/addSupply.php?rfc=" + txtCorporationName.getText().toString() +
                "&mail=" + txtMail.getText().toString() +
                "&numberphone=" + txtNumberPhone.getText().toString() +
                "&addres=" + txtNameAddres.getText().toString() +
                "&numberaddres=" + txtNumberAddres.getText().toString() +
                "&location=" + txtLocation.getText().toString() +
                "&cp=" + txtCP.getText().toString() +
                "&state=" + txtState.getText().toString() +
                "&city=" + txtCity.getText().toString() +
                "&country=" + txtCountry.getText().toString();

        url = url.replace(" ", "%20");

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        request.add(jsonObjectRequest);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        progreso.hide();
        Toast.makeText(getContext(), getString(R.string.insusessfull) + error, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getContext(), getString(R.string.susessfull), Toast.LENGTH_SHORT).show();
        progreso.hide();
        txtCorporationName.setText("");
        txtNumberPhone.setText("");
        txtMail.setText("");
        txtNameAddres.setText("");
        txtNumberAddres.setText("");
        txtCP.setText("");
        txtLocation.setText("");
        txtCity.setText("");
        txtState.setText("");
        txtCountry.setText("");
        changeFragment(ManagerFragmentSupply.SUPPLY);


    }


    private void alertExit() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                getContext());
        alertDialogBuilder.setTitle(getString(R.string.alertExit));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                changeFragment(ManagerFragmentSupply.SUPPLY);
            }
        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void backButton() {
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @SuppressLint("WrongConstant")
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    //validation();
                    return true;
                }
                return false;
            }
        });
    }


//    private void validation() {
//
//
//        txtCorporationName = view.findViewById(R.id.txtCorporationName);
//        txtNumberPhone = view.findViewById(R.id.txtNumberPhone);
//        txtMail = view.findViewById(R.id.txtMail);
//        txtNameAddres = view.findViewById(R.id.txtNameAddres);
//        txtNumberAddres = view.findViewById(R.id.txtNumberAddres);
//        txtCP = view.findViewById(R.id.txtCP);
//        txtLocation = view.findViewById(R.id.txtLocation);
//        txtCity = view.findViewById(R.id.txtCity);
//        txtState = view.findViewById(R.id.txtState);
//        txtCountry = view.findViewById(R.id.txtCountry);
//
//
//        if (txtCorporationName.getText().length()<=0){
//            txtCorporationName.setError(getString(R.string.error));
//        }
//
//        if (txtNumberPhone.getText().length() <= 0) {
//            txtNumberPhone.setError(getString(R.string.error));
//        }
//        if (txtMail.getText().length() <= 0) {
//            txtMail.setError(getString(R.string.error));
//
//        }
//        if (txtNameAddres.getText().length() <= 0) {
//            txtNameAddres.setError(getString(R.string.error));
//
//        }
//        if (txtNumberAddres.getText().length() <= 0) {
//            txtNumberAddres.setError(getString(R.string.error));
//
//        }
//        if (txtCP.getText().length() <= 0) {
//            txtCP.setError(getString(R.string.error));
//
//        }
//        if (txtLocation.getText().length() <= 0) {
//            txtLocation.setError(getString(R.string.error));
//
//        }
//        if (txtCity.getText().length() <= 0) {
//            txtCity.setError(getString(R.string.error));
//
//        }
//        if (txtState.getText().length() <= 0) {
//            txtState.setError(getString(R.string.error));
//
//        }
//        if (txtCountry.getText().length() <= 0) {
//            txtCountry.setError(getString(R.string.error));
//
//        } else {
//            openAlert();
//        }
//    }

    private void openAlert() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                getContext());
        alertDialogBuilder.setTitle(getString(R.string.alertSupply));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                changeFragment(ManagerFragmentSupply.SUPPLY);
            }
        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();


    }

    private void changeFragment(ManagerFragmentSupply state) {
        this.state = ManagerFragmentSupply.setState(state);
        this.state.execute((MainContainerSupply) getContext());
    }


}
