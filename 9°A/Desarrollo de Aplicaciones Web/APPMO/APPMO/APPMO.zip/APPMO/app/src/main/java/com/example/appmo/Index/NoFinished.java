package com.example.appmo.Index;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.appmo.R;

import java.util.ArrayList;
import java.util.List;


public class NoFinished extends Fragment {
    View view;
    //a list to store all the products
    List<Order> productList;

    //the recyclerview
    RecyclerView recyclerView;


    public NoFinished() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_no_finished, container, false);
        cardView();
        return view;
    }


    public void cardView() {
        //getting the recyclerview from xml
        recyclerView = view.findViewById(R.id.recyclerViewIndex);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        //initializing the productlist
        productList = new ArrayList<>();

        productList.add(
                new Order(
                        1,
                        "Sr. Juliana de la Cruz antonia Sanchez ",
                        "400 pz",
                        "San Cristobal de las casas"
                ));
        productList.add(
                new Order(
                        2,
                        "Sr. Juliana ",
                        "400 pz",
                        "San Cristobal de las casas"
                ));
        productList.add(
                new Order(
                        3,
                        "Sr. Juliana ",
                        "400 pz",
                        "San Cristobal de las casas"
                ));
        productList.add(
                new Order(
                        3,
                        "Sr. Juliana ",
                        "400 pz",
                        "San Cristobal de las casas"
                ));
        productList.add(
                new Order(
                        3,
                        "Sr. Juliana ",
                        "400 pz",
                        "San Cristobal de las casas"
                ));


        //creating recyclerview adapter
        OderAdapter adapter = new OderAdapter(getContext(), productList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

}
