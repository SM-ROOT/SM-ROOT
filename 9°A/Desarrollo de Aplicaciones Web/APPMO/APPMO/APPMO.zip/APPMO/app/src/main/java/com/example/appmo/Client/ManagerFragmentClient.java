package com.example.appmo.Client;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.example.appmo.Index.Finished;
import com.example.appmo.Index.MainContainerIndex;
import com.example.appmo.Index.NoFinished;
import com.example.appmo.R;

public enum ManagerFragmentClient {

    CLIENTINDEX {
        @Override
        public Fragment execute(MainContainerClient activity) {
            return setFragment(activity, R.id.FragmentContainerClient, ClientIndex.class);
        }
    },
    CLIENTADD {
        @Override
        public Fragment execute(MainContainerClient activity) {
            return setFragment(activity, R.id.FragmentContainerClient, AddClient.class);
        }
    };


    public abstract Fragment execute(MainContainerClient activity);

    //Variables
    public Bundle bundle;

    public Fragment setFragment(MainContainerClient activity, int id, Class<? extends Fragment> fragmentclass) {

        Fragment newFragment = null;
        try {
            newFragment = fragmentclass.newInstance();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }

        FragmentManager manager = activity.getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(id, newFragment, fragmentclass.getCanonicalName());
        transaction.commit();
        return newFragment;
    }

    public static ManagerFragmentClient setState(ManagerFragmentClient newState) {
        ManagerFragmentClient state = newState;
        return state;
    }

    public Bundle getBundle() {
        return bundle;
    }

    public ManagerFragmentClient setBundle(Bundle bundle) {
        this.bundle = bundle;
        return this;
    }

}