package com.example.appmo.RoomStock;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.appmo.R;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Product> ProductList;

    //getting the context and product list with constructor
    public ProductAdapter(Context mCtx, List<Product> ProductList) {
        this.mCtx = mCtx;
        this.ProductList = ProductList;
    }

    @Override
    public ProductAdapter.ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_view_product, null);
        return new ProductAdapter.ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        //getting the product of the specified position
        Product item = ProductList.get(position);


        //binding the data with the viewholder views
        holder.NameProduct.setText(item.getName());
        holder.QuantityProduct.setText(item.getQuantity());
        holder.PriceProduct.setText(item.getPrice());



    }


    @Override
    public int getItemCount() {
        return ProductList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView NameProduct, QuantityProduct, PriceProduct;


        public ProductViewHolder(View itemView) {
            super(itemView);

            NameProduct = itemView.findViewById(R.id.tvNameProduct);
            QuantityProduct = itemView.findViewById(R.id.txtQuantityProduct);
            PriceProduct = itemView.findViewById(R.id.txtPriceProduct);



        }
    }
}