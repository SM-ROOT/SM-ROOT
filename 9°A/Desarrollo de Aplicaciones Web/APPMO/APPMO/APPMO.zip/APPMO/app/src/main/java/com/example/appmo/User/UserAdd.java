package com.example.appmo.User;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.appmo.R;
import com.example.appmo.infoIP;

import org.json.JSONObject;


public class UserAdd extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    public static ManagerFragmentUser state;
    String ip = new  infoIP().getIp();
    View view;
    EditText txtName, txtSubNamePather, txtSubNameMother, txtMail, txtNumberPhone, txtType, txtPassword,
            txtNameAddres, txtNumberAddres, txtColony, txtCp, txtCity, txtState, txtCountry;
    ImageView btnSave, btnCancel;
    ProgressDialog progreso;

    /**
     * Para establecer la conexion directa con el Web Service
     */
    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;


    public UserAdd() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_user, container, false);
        saveUser();
        return view;
    }

    private void saveUser() {
        txtName = view.findViewById(R.id.txtRfc);
        txtSubNamePather = view.findViewById(R.id.txtSubNamePather);
        txtSubNameMother = view.findViewById(R.id.txtSubNameMother);
        txtMail = view.findViewById(R.id.txtMail);
        txtNumberPhone = view.findViewById(R.id.txtNumberPhone);
        txtType = view.findViewById(R.id.txtType);
        txtPassword = view.findViewById(R.id.txtPassword);
        txtNameAddres = view.findViewById(R.id.txtNameAddres);
        txtNumberAddres = view.findViewById(R.id.txtNumberAddres);
        txtColony = view.findViewById(R.id.txtColony);
        txtCp = view.findViewById(R.id.txtCp);
        txtCity = view.findViewById(R.id.txtCity);
        txtState = view.findViewById(R.id.txtState);
        txtCountry = view.findViewById(R.id.txtCountry);

        request = Volley.newRequestQueue(getContext());

        btnSave = view.findViewById(R.id.btnSaveUser);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarWebService();
            }
        });
        btnCancel = view.findViewById(R.id.btnCancelUser);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertCancel();

            }
        });


    }

    private void cargarWebService() {
        progreso = new ProgressDialog(getContext());
        progreso.setMessage("Cargando...");
        progreso.show();


        String url = "http://" + ip + "/appmo/addUser.php?name=" + txtName.getText().toString() +
                "&subnamepather=" + txtSubNamePather.getText().toString() +
                "&subnamemother=" + txtSubNameMother.getText().toString() +
                "&mail=" + txtMail.getText().toString() +
                "&numberphone=" + txtNumberPhone.getText().toString() +
                "&type=" + txtType.getText().toString() +
                "&password=" + txtPassword.getText().toString() +
                "&addres=" + txtNameAddres.getText().toString() +
                "&numberaddres=" + txtNumberAddres.getText().toString() +
                "&colony=" + txtColony.getText().toString() +
                "&cp=" + txtCp.getText().toString() +
                "&city=" + txtCity.getText().toString() +
                "&state=" + txtState.getText().toString() +
                "&country=" + txtCountry.getText().toString();

        url = url.replace(" ", "%20");

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        request.add(jsonObjectRequest);

    }

    private void alertCancel() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                getContext());
        alertDialogBuilder.setTitle(getString(R.string.alertExit));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                changeFragment(ManagerFragmentUser.USERINDEX);
            }
        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getContext(), getString(R.string.susessfull), Toast.LENGTH_SHORT).show();
        progreso.hide();
        txtName.setText("");
        txtSubNamePather.setText("");
        txtSubNameMother.setText("");
        txtMail.setText("");
        txtNumberPhone.setText("");
        txtType.setText("");
        txtPassword.setText("");
        txtNameAddres.setText("");
        txtNumberAddres.setText("");
        txtColony.setText("");
        txtCp.setText("");
        txtCity.setText("");
        txtState.setText("");
        txtCountry.setText("");
        changeFragment(ManagerFragmentUser.USERINDEX);

    }

    @Override
    public void onErrorResponse(VolleyError error) {
        progreso.hide();
        Toast.makeText(getContext(), getString(R.string.insusessfull) + error, Toast.LENGTH_SHORT).show();

    }

    private void changeFragment (ManagerFragmentUser state){
        this.state = ManagerFragmentUser.setState(state);
        this.state.execute((MainContainerUser) getContext());
    }


}
