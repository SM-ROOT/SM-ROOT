package com.example.appmo;

public class infoIP {


   private String infoIp = "192.168.0.113";

    public String getIp() {
        return infoIp;

    }

}
