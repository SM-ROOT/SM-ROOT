package com.example.appmo.RoomStock;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.appmo.R;
import com.example.appmo.User.ManagerFragmentUser;
import com.example.appmo.User.User;
import com.example.appmo.User.UserAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class RoomStockIndex extends Fragment {
    public static ManagerFragmentRoomStock state;

    View view;
    //a list to store all the products
    List<Product> productList;

    //the recyclerview
    RecyclerView recyclerView;


    public RoomStockIndex() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_product_list, container, false);
        addProduct();
        cardviewProduct();
        return view;
    }

    private void cardviewProduct() {
        //getting the recyclerview from xml
        recyclerView = view.findViewById(R.id.recyclerViewProduct);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        //initializing the productlist
        productList = new ArrayList<>();

        productList.add(
                new Product(
                        "Maria",
                        "Jose Miguel ",
                        "Lopez"

                ));
        productList.add(
                new Product(
                        "Ma",
                        "Miriam Carolina",
                        "Jimenez"

                ));

        productList.add(
                new Product(
                        "Maria",
                        "Jose Miguel ",
                        "Lopez"

                ));
        productList.add(
                new Product(
                        "Ma",
                        "Miriam Carolina",
                        "Jimenez"

                ));
        productList.add(
                new Product(
                        "Maria",
                        "Jose Miguel ",
                        "Lopez"

                ));
        productList.add(
                new Product(
                        "Ma",
                        "Miriam Carolina",
                        "Jimenez"

                ));


        //creating recyclerview adapter
        ProductAdapter adapter = new ProductAdapter(getContext(), productList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

    private void addProduct() {
        FloatingActionButton fabAddProduct= view.findViewById(R.id.fabAddProduct);
        fabAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(ManagerFragmentRoomStock.PRODUCTADD);

            }
        });
    }

    private void changeFragment (ManagerFragmentRoomStock state){
        this.state= ManagerFragmentRoomStock.setState(state);
        this.state.execute((MainContainerRoomStock) getContext());
    }

}
