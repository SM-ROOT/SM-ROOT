package com.example.appmo.User;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.appmo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class UserIndex extends Fragment {
    public static ManagerFragmentUser state;
    View view;
    //a list to store all the products
    List<User> userList;

    //the recyclerview
    RecyclerView recyclerView;


    public UserIndex() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_user_index, container, false);
        cardView();
        showToolBar();
        addUser();
        return view;
    }

    private void addUser() {
        FloatingActionButton fabAddUser = view.findViewById(R.id.fabAddUser);
        fabAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment(ManagerFragmentUser.ADD_USER);

            }
        });
    }

    private void showToolBar() {
        Toolbar toolbar = view.findViewById(R.id.toolbar);
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);
        final ActionBar actionBar = ((AppCompatActivity) getActivity()).getSupportActionBar();
        actionBar.setTitle(getString(R.string.titleUser));
        /*toolbar.setNavigationOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

            }
        });*/

    }

    public void cardView() {
        //getting the recyclerview from xml
        recyclerView = view.findViewById(R.id.recyclerViewUser);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        //initializing the productlist
        userList = new ArrayList<>();

        userList.add(
                new User(
                        1,
                        "Jose Miguel ",
                        "Lopez",
                        "Guillen",
                        "26 Años",
                        "Por el momento no hay Photo",
                        "Antonio_Guillen@gmail.com",
                        "Administrador",
                        "admin123",
                        "963-138-2799",
                        "Prolongación de la 8° Calle sur poniente",
                        "14",
                        "Fracc. Las Flores",
                        "30065",
                        "Chiapas",
                        "Comitán de Dominguez",
                        "México"

                ));
        userList.add(
                new User(
                        1,
                        "Miriam Carolina",
                        "Jimenez",
                        "Lopez",
                        "20 años",
                        "No se encuentra",
                        "karitho.lopez.1998.miriam@gmail.com",
                        "Secretaria",
                        "admin123",
                        "963-187-7454",
                        "Fraccionamiento las flores",
                        "14",
                        "Fracc. Las Flores",
                        "30065",
                        "Chiapas",
                        "Comitan de Dominguez",
                        "México"

                ));


        //creating recyclerview adapter
        UserAdapter adapter = new UserAdapter(getContext(), userList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

    private void changeFragment (ManagerFragmentUser state){
        this.state= ManagerFragmentUser.setState(state);
        this.state.execute((MainContainerUser) getContext());
    }

}
