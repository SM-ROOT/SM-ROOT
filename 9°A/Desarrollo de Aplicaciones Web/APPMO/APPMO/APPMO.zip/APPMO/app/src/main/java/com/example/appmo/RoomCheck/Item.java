package com.example.appmo.RoomCheck;

public class Item {
    private int idProductRooomCheck;
    private String nameProductRoomCheck;
    private String typeProductRoomCheck;
    private String quantityProductRoomCheck;

    public Item(int idProductRooomCheck, String nameProductRoomCheck,
                String typeProductRoomCheck, String quantityProductRoomCheck) {
        this.idProductRooomCheck = idProductRooomCheck;
        this.nameProductRoomCheck = nameProductRoomCheck;
        this.typeProductRoomCheck = typeProductRoomCheck;
        this.quantityProductRoomCheck = quantityProductRoomCheck;
    }

    public int getIdProductRooomCheck() {
        return idProductRooomCheck;
    }

    public void setIdProductRooomCheck(int idProductRooomCheck) {
        this.idProductRooomCheck = idProductRooomCheck;
    }

    public String getNameProductRoomCheck() {
        return nameProductRoomCheck;
    }

    public void setNameProductRoomCheck(String nameProductRoomCheck) {
        this.nameProductRoomCheck = nameProductRoomCheck;
    }

    public String getTypeProductRoomCheck() {
        return typeProductRoomCheck;
    }

    public void setTypeProductRoomCheck(String typeProductRoomCheck) {
        this.typeProductRoomCheck = typeProductRoomCheck;
    }

    public String getQuantityProductRoomCheck() {
        return quantityProductRoomCheck;
    }

    public void setQuantityProductRoomCheck(String quantityProductRoomCheck) {
        this.quantityProductRoomCheck = quantityProductRoomCheck;
    }
}
