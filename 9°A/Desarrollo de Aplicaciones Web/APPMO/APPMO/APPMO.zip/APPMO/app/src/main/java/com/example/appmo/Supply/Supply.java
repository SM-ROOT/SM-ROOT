package com.example.appmo.Supply;

public class Supply {
    private int idNameSupplModel;
    private String nameSupply;
    private String numberSupply;
    private String mailSupply;
    private String addresSupply;
    private String numAddresSSupply;
    private String locationSupply;
    private String cpSupply;
    private String stateSupply;
    private String citySupply;
    private String countrySupply;

    public Supply(int idNameSupplModel, String nameSupply, String numberSupply, String mailSupply,
                  String addresSupply, String numAddresSSupply, String locationSupply, String cpSupply,
                  String stateSupply, String citySupply, String countrySupply) {

        this.idNameSupplModel = idNameSupplModel;
        this.nameSupply = nameSupply;
        this.numberSupply = numberSupply;
        this.mailSupply = mailSupply;
        this.addresSupply = addresSupply;
        this.numAddresSSupply = numAddresSSupply;
        this.locationSupply = locationSupply;
        this.cpSupply = cpSupply;
        this.stateSupply = stateSupply;
        this.citySupply = citySupply;
        this.countrySupply = countrySupply;
    }

    public int getIdNameSupplModel() {
        return idNameSupplModel;
    }

    public void setIdNameSupplModel(int idNameSupplModel) {
        this.idNameSupplModel = idNameSupplModel;
    }

    public String getNameSupply() {
        return nameSupply;
    }

    public void setNameSupply(String nameSupply) {
        this.nameSupply = nameSupply;
    }

    public String getNumberSupply() {
        return numberSupply;
    }

    public void setNumberSupply(String numberSupply) {
        this.numberSupply = numberSupply;
    }

    public String getMailSupply() {
        return mailSupply;
    }

    public void setMailSupply(String mailSupply) {
        this.mailSupply = mailSupply;
    }

    public String getAddresSupply() {
        return addresSupply;
    }

    public void setAddresSupply(String addresSupply) {
        this.addresSupply = addresSupply;
    }

    public String getNumAddresSSupply() {
        return numAddresSSupply;
    }

    public void setNumAddresSSupply(String numAddresSSupply) {
        this.numAddresSSupply = numAddresSSupply;
    }

    public String getLocationSupply() {
        return locationSupply;
    }

    public void setLocationSupply(String locationSupply) {
        this.locationSupply = locationSupply;
    }

    public String getCpSupply() {
        return cpSupply;
    }

    public void setCpSupply(String cpSupply) {
        this.cpSupply = cpSupply;
    }

    public String getStateSupply() {
        return stateSupply;
    }

    public void setStateSupply(String stateSupply) {
        this.stateSupply = stateSupply;
    }

    public String getCitySupply() {
        return citySupply;
    }

    public void setCitySupply(String citySupply) {
        this.citySupply = citySupply;
    }

    public String getCountrySupply() {
        return countrySupply;
    }

    public void setCountry(String getCountrySupply) {
        this.countrySupply = getCountrySupply;
    }
}
