package com.example.appmo.Splash;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.appmo.Index.MainContainerIndex;
import com.example.appmo.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Login extends Fragment {
    View view;
    Button btnEntryIndex, btnNewPasswordLogin;
    EditText txtUser, txtPassword;
    private static ManagerFragmentSplash states;


    public Login() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_login, container, false);
        openIndex();
        openNewPassword();
        return view;
    }

    private void openNewPassword() {
        btnNewPasswordLogin = view.findViewById(R.id.btnNewPassword);
        btnNewPasswordLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(ManagerFragmentSplash.NEWPASSWORD);
            }
        });

    }

    private void openIndex() {
        btnEntryIndex = view.findViewById(R.id.btnEntryIndex);
        txtUser = view.findViewById(R.id.txtMail);
        txtPassword = view.findViewById(R.id.txtImputPassword);

        btnEntryIndex.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (txtUser.getText().length() == 0) {
                    txtUser.setError(getString(R.string.txtErrorMatriLogin));
                    txtUser.getText().clear();

                } else if (txtPassword.getText().length() == 0) {
                    txtPassword.setError(getString(R.string.txtErrorPasswordLogin));
                    txtPassword.getText().clear();


                } else {
                    Intent Index;
                    Index = new Intent(getContext(), MainContainerIndex.class);
                    startActivity(Index);

                }


            }
        });
    }

    private void changeFragment(ManagerFragmentSplash states) {
        this.states = ManagerFragmentSplash.setState(states);
        this.states.execute((MainContainerSplash) getContext());
    }

}
