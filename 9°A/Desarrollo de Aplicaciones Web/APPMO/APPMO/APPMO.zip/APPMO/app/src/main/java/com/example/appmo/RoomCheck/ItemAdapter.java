package com.example.appmo.RoomCheck;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.appmo.R;

import java.util.List;


public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Item> itemList;

    //getting the context and product list with constructor
    public ItemAdapter(Context mCtx, List<Item> itemList) {
        this.mCtx = mCtx;
        this.itemList = itemList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_view_room_check, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        //getting the product of the specified position
        Item item = itemList.get(position);


        //binding the data with the viewholder views
        holder.tvNameProductRoomCheck.setText(item.getNameProductRoomCheck());
        holder.tvTypeProductRoomCheck.setText(item.getTypeProductRoomCheck());
        holder.tvQuantityProductRoomCheck.setText(item.getQuantityProductRoomCheck());



//        holder.showAdpaterDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                AlertDialog.Builder showAlert = new AlertDialog.Builder(mCtx);
//                showAlert.setTitle(R.string.dateorder)
//                        .setMessage("Nombre: " + holder.tvNameOrder.getText() + "\n" +
//                                "Cantidad: " + holder.tvQualitityOrder.getText() + "\n" +
//                                "Destino: " + holder.tvDestinationOrder.getText())
//                        .setNegativeButton((R.string.cancel), new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//
//                            }
//                        })
//                        .setPositiveButton((R.string.accept), new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//
//
//                            }
//                        });
//
//                showAlert.create();
//                showAlert.show();
//            }
//            });

    }


    @Override
    public int getItemCount() {
        return itemList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView tvNameProductRoomCheck, tvTypeProductRoomCheck, tvQuantityProductRoomCheck;

        public ProductViewHolder(View itemView) {
            super(itemView);

            tvNameProductRoomCheck = itemView.findViewById(R.id.tvNameProductRoomCheck);
            tvTypeProductRoomCheck = itemView.findViewById(R.id.tvTypeProductRoomCheck);
            tvQuantityProductRoomCheck = itemView.findViewById(R.id.tvQuantityProductRoomCheck);
        }
    }
}
