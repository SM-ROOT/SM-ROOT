package com.example.appmo.Supply;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.appmo.R;

import java.util.List;

public class SupplyAdapter extends RecyclerView.Adapter<SupplyAdapter.SupplyViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<Supply> supplyList;

    //getting the context and product list with constructor
    public SupplyAdapter(Context mCtx, List<Supply> supplyList) {
        this.mCtx = mCtx;
        this.supplyList = supplyList;
    }

    @Override
    public SupplyAdapter.SupplyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_view_supply, null);
        return new SupplyAdapter.SupplyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final SupplyAdapter.SupplyViewHolder holder, final int position) {
        //getting the product of the specified position
        Supply item = supplyList.get(position);


        //binding the data with the viewholder views
        holder.NameSupply.setText(item.getNameSupply());
        holder.NumberSupply.setText(item.getNumberSupply());
        holder.MailSupply.setText(item.getMailSupply());
        holder.AddresSupply.setText(item.getAddresSupply());
        holder.NumAddresSSupply.setText(item.getNumAddresSSupply());
        holder.LocationSupply.setText(item.getLocationSupply());
        holder.CpSupply.setText(item.getCpSupply());
        holder.StateSupply.setText(item.getStateSupply());
        holder.CitySupply.setText(item.getCitySupply());
        holder.CountrySupply.setText(item.getCountrySupply());


    }


    @Override
    public int getItemCount() {
        return supplyList.size();
    }


    class SupplyViewHolder extends RecyclerView.ViewHolder {

        TextView NameSupply, NumberSupply, MailSupply, AddresSupply, NumAddresSSupply,
                LocationSupply, CpSupply, StateSupply, CitySupply, CountrySupply;


        public SupplyViewHolder(View itemView) {
            super(itemView);

            NameSupply = itemView.findViewById(R.id.tvNameSupply);
            MailSupply = itemView.findViewById(R.id.tvNameUserPather);
            NumberSupply = itemView.findViewById(R.id.tvNameUserMother);
            AddresSupply = itemView.findViewById(R.id.tvNumberUser);
            NumAddresSSupply = itemView.findViewById(R.id.tvNumAddresSSupply);
            LocationSupply = itemView.findViewById(R.id.tvMailUser);
            CpSupply = itemView.findViewById(R.id.tvTypeUser);
            StateSupply = itemView.findViewById(R.id.tvpasswordUser);
            CitySupply = itemView.findViewById(R.id.tvAddresUser);
            CountrySupply = itemView.findViewById(R.id.tvCpUser);


        }
    }
}