package com.example.appmo.Client;


import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.appmo.R;
import com.example.appmo.RoomStock.ManagerFragmentRoomStock;
import com.example.appmo.infoIP;

import org.json.JSONObject;

/**
 * A simple {@link Fragment} subclass.
 */
public class AddClient extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {
    public static ManagerFragmentClient state;
    //help, help no se programar, estoy practicando...
    View view;
    String ip = new infoIP().getIp();
    EditText txtRfc, txtNumberPhone, txtMail, txtAddres, txtNumberAddres, txtCp, txtColony, txtCity, txtState, txtCountry;
    ImageView btnSaveClient, btnCancelClient;
    ProgressDialog progress;

    RequestQueue request;
    JsonObjectRequest jsonObjectRequest;


    public AddClient() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         view =inflater.inflate(R.layout.fragment_add_client, container, false);
         addClient();
         return view;
    }

    private void addClient() {
        txtRfc = view.findViewById(R.id.txtRfc);
        txtNumberPhone= view.findViewById(R.id.txtNumberPhone);
        txtMail = view.findViewById(R.id.txtMail);
        txtAddres = view.findViewById(R.id.txtAddres);
        txtNumberAddres = view.findViewById(R.id.txtNumberAddres);
        txtCp = view.findViewById(R.id.txtCp);
        txtColony = view.findViewById(R.id.txtColony);
        txtCity = view.findViewById(R.id.txtCity);
        txtState = view.findViewById(R.id.txtState);
        txtCountry = view.findViewById(R.id.txtCountry);

        request = Volley.newRequestQueue(getContext());

        btnSaveClient = view.findViewById(R.id.btnSaveClient);
        btnSaveClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadWebService();
            }
        });

        btnCancelClient = view.findViewById(R.id.btnCancelClient);
        btnCancelClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertCancel();
            }
        });
    }

    private void alertCancel() {
        android.app.AlertDialog.Builder alertDialogBuilder = new android.app.AlertDialog.Builder(
                getContext());
        alertDialogBuilder.setTitle(getString(R.string.alertExit));
        alertDialogBuilder.setPositiveButton(getString(R.string.accept), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                changeFragment(ManagerFragmentRoomStock.ROOMSTOCKINDEX);
            }

        })
                .setNegativeButton(getString(R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                            }
                        });

        android.app.AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void changeFragment(ManagerFragmentRoomStock state) {
        this.state = ManagerFragmentClient.CLIENTINDEX;
        this.state.execute((MainContainerClient) getContext());
    }


    private void loadWebService() {
        progress = new ProgressDialog(getContext());
        progress.setMessage(getString(R.string.load));
        progress.show();

        String url = "http://"+ ip +"/appmo/addClient.php?rfc="+txtRfc.getText().toString()+
                "&numberPhone="+txtNumberPhone.getText().toString()+
                "&mail="+txtMail.getText().toString()+
                "&addres="+txtAddres.getText().toString()+
                "&numberaddres="+txtNumberAddres.getText().toString()+
                "&cp="+txtCp.getText().toString()+
                "&colony="+txtColony.getText().toString()+
                "&city="+txtCity.getText().toString() +
                "&state="+txtState.getText().toString()+
                "&country="+txtCountry.getText().toString();

        url = url.replace(" ", "%20");

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        request.add(jsonObjectRequest);

    }

    @Override
    public void onErrorResponse(VolleyError error) {

    }

    @Override
    public void onResponse(JSONObject response) {

    }
}
