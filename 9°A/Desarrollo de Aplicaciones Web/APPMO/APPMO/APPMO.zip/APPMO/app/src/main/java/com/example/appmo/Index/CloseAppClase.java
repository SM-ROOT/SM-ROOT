package com.example.appmo.Index;

import android.app.Service;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.example.appmo.R;


public class CloseAppClase extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        getSystemService(Service.ACTIVITY_SERVICE);
        Toast.makeText(this, "ADIOS :)", Toast.LENGTH_SHORT).show();
        setContentView(R.layout.activity_closeapp);
        System.exit(0);

    }
}
