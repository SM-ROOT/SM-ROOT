package com.example.appmo.User;

public class User {
    private int idUser;
    private String nameUser;
    private String subNamePather;
    private String SubNameMother;
    private String ageUser;
    private String photo;
    private String mailUser;
    private String typedUser;
    private String passwordUser;
    private String numberPhoneUser;
    private String addresUser;
    private String addresNumberUser;
    private String locationUser;
    private String cpUser;
    private String stateUser;
    private String cityUser;
    private String countryUser;

    public User(int idUser, String nameUser,
                String subNamePather, String SubNameMother,
                String ageUser, String photo, String mailUser,
                String typedUser, String passwordUser, String numberPhoneUser,
                String addresUser, String addresNumberUser, String locationUser,
                String cpUser, String stateUser, String cityUser, String countryUser) {
        this.idUser = idUser;
        this.nameUser = nameUser;
        this.subNamePather = subNamePather;
        this.SubNameMother = SubNameMother;
        this.ageUser = ageUser;
        this.photo = photo;
        this.mailUser = mailUser;
        this.typedUser = typedUser;
        this.passwordUser = passwordUser;
        this.numberPhoneUser = numberPhoneUser;
        this.addresUser = addresUser;
        this.addresNumberUser = addresNumberUser;
        this.locationUser = locationUser;
        this.cpUser = cpUser;
        this.stateUser = stateUser;
        this.cityUser = cityUser;
        this.countryUser = countryUser;
    }

    public int getIdUser() {
        return idUser;
    }

    public void setIdUser(int idUser) {
        this.idUser = idUser;
    }

    public String getNameUser() {
        return nameUser;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }

    public String getSubNamePather() {
        return subNamePather;
    }

    public void setSubNamePather(String subNamePather) {
        this.subNamePather = subNamePather;
    }

    public String getSubNameMother() {
        return SubNameMother;
    }

    public void setSubNameMother(String subNameMother) {
        SubNameMother = subNameMother;
    }

    public String getAgeUser() {
        return ageUser;
    }

    public void setAgeUser(String ageUser) {
        this.ageUser = ageUser;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getMailUser() {
        return mailUser;
    }

    public void setMailUser(String mailUser) {
        this.mailUser = mailUser;
    }

    public String getTypedUser() {
        return typedUser;
    }

    public void setTypedUser(String typedUser) {
        this.typedUser = typedUser;
    }

    public String getPasswordUser() {
        return passwordUser;
    }

    public void setPasswordUser(String passwordUser) {
        this.passwordUser = passwordUser;
    }

    public String getNumberPhoneUser() {
        return numberPhoneUser;
    }

    public void setNumberPhoneUser(String numberPhoneUser) {
        this.numberPhoneUser = numberPhoneUser;
    }

    public String getAddresUser() {
        return addresUser;
    }

    public void setAddresUser(String addresUser) {
        this.addresUser = addresUser;
    }

    public String getAddresNumberUser() {
        return addresNumberUser;
    }

    public void setAddresNumberUser(String addresNumberUser) {
        this.addresNumberUser = addresNumberUser;
    }

    public String getLocationUser() {
        return locationUser;
    }

    public void setLocationUser(String locationUser) {
        this.locationUser = locationUser;
    }

    public String getCpUser() {
        return cpUser;
    }

    public void setCpUser(String cpUser) {
        this.cpUser = cpUser;
    }

    public String getStateUser() {
        return stateUser;
    }

    public void setStateUser(String stateUser) {
        this.stateUser = stateUser;
    }

    public String getCityUser() {
        return cityUser;
    }

    public void setCityUser(String cityUser) {
        this.cityUser = cityUser;
    }

    public String getCountryUser() {
        return countryUser;
    }

    public void setCountryUser(String countryUser) {
        this.countryUser = countryUser;
    }






}
