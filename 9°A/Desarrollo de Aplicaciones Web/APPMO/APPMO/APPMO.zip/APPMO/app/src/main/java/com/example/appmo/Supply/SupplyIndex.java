package com.example.appmo.Supply;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.appmo.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class SupplyIndex extends Fragment {
    public static ManagerFragmentSupply states;
    View view;

    //a list to store all the products
    List<Supply> supplyList;

    //the recyclerview
    RecyclerView recyclerView;

    public SupplyIndex() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_supply, container, false);
        addSupply();
        cardView();
        return view;
    }

    private void addSupply() {
        FloatingActionButton fabAddUser= view.findViewById(R.id.fabAddSupply);
        fabAddUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                changeFragment(ManagerFragmentSupply.ADDSUPPLY);
            }
        });
    }

    public void cardView() {
        //getting the recyclerview from xml
        recyclerView = view.findViewById(R.id.recyclerViewSupply);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        //initializing the productlist
        supplyList = new ArrayList<>();

        supplyList.add(
                new Supply(
                        1,
                        "jOSE aN",
                        "400 pz",
                        "San Cristobal de las casas",
                        "asdasd",
                        "asdasdqwq",
                        "asdasdac",
                        "asdasdax",
                        "asdasdasd",
                        "sdqw",
                        "asdasdqwe"

                ));
        supplyList.add(
                new Supply(
                        1,
                        "Sr. Juliana de la Cruz antonia Sanchez ",
                        "400 pz",
                        "San Cristobal de las casas",
                        "asdfasdf",
                        "sdfasdfasd",
                        "sdfasdf",
                        "asdsdf",
                        "sdfasdf",
                        "sdfasdf",
                        "sdfasdfasdf"

                ));
        supplyList.add(
                new Supply(
                        1,
                        "Sr. Juliana de la Cruz antonia Sanchez ",
                        "400 pz",
                        "San Cristobal de las casas",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        ""

                ));


        //creating recyclerview adapter
        SupplyAdapter adapter = new SupplyAdapter(getContext(), supplyList);

        //setting adapter to recyclerview
        recyclerView.setAdapter(adapter);
    }

    public void changeFragment(ManagerFragmentSupply states){
        this.states= ManagerFragmentSupply.setState(states);
        this.states.execute((MainContainerSupply) getContext());
    }

}
