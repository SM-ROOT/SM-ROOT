package com.example.appmo.User;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.appmo.R;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<User> UserList;

    //getting the context and product list with constructor
    public UserAdapter(Context mCtx, List<User> UserList) {
        this.mCtx = mCtx;
        this.UserList = UserList;
    }

    @Override
    public UserAdapter.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.card_view_user, null);
        return new UserAdapter.UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final UserViewHolder holder, final int position) {
        //getting the product of the specified position
        User item = UserList.get(position);


        //binding the data with the viewholder views
        holder.NameUser.setText(item.getNameUser());
        holder.NameUserPather.setText(item.getSubNamePather());
        holder.NameUserMother.setText(item.getSubNameMother());
        holder.MailUser.setText(item.getMailUser());
        holder.TypeUser.setText(item.getTypedUser());
        holder.passwordUser.setText(item.getPasswordUser());
        holder.Photo.setText(item.getPhoto());
        holder.AddresUser.setText(item.getAddresUser());
        holder.NumAddresUser.setText(item.getAddresNumberUser());
        holder.LocationUser.setText(item.getLocationUser());
        holder.CpUser.setText(item.getCpUser());
        holder.StateUser.setText(item.getStateUser());
        holder.CityUser.setText(item.getCityUser());
        holder.CountryUser.setText(item.getCountryUser());


    }


    @Override
    public int getItemCount() {
        return UserList.size();
    }


    class UserViewHolder extends RecyclerView.ViewHolder {

        TextView NameUser, NameUserPather, NameUserMother, NumberUser, MailUser ,NumAddresUser, AddresUser,
                LocationUser, CpUser, StateUser, CityUser, CountryUser, TypeUser, passwordUser, Photo;


        public UserViewHolder(View itemView) {
            super(itemView);

            NameUser = itemView.findViewById(R.id.tvNameSupply);
            NameUserPather = itemView.findViewById(R.id.tvNameUserPather);
            NameUserMother = itemView.findViewById(R.id.tvNameUserMother);
            NumberUser = itemView.findViewById(R.id.tvNumberUser);
            MailUser = itemView.findViewById(R.id.tvMailUser);
            TypeUser = itemView.findViewById(R.id.tvTypeUser);
            Photo = itemView.findViewById(R.id.tvPhoto);
            passwordUser= itemView.findViewById(R.id.tvpasswordUser);
            AddresUser = itemView.findViewById(R.id.tvAddresUser);
            NumAddresUser = itemView.findViewById(R.id.tvNumAddresUser);
            LocationUser = itemView.findViewById(R.id.tvLocationUser);
            CpUser= itemView.findViewById(R.id.tvCpUser);
            StateUser = itemView.findViewById(R.id.tvStateUser);
            CityUser = itemView.findViewById(R.id.tvCityUser);
            CountryUser = itemView.findViewById(R.id.tvCountryUser);


        }
    }
}